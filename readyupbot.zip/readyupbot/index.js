
// Author: Travis Ray Wills
// To anyone reading this code, I would like to apologise for the mess you are about to witness.

const Discord = require("discord.js")
const botClient = new Discord.Client();
const botChannelName = 'bot-readyup';
const readiedIcon = "^ ";
var queueList = [];

// Ready management class ------------------------------------------------------
class readyQueue {
	constructor(guild){
		this.guild = guild;
		this.channel = this.guild.channels.cache.find(channel => channel.name === 'bot-readyup');
		this.ready = []; // Type: member.
		this.unready = []; // Type: member.
		this.guild.members.cache.filter(member => !member.user.bot).forEach((m, i) => { // Fill unready array with all non-bot members.
			this.unready.push(m);
		});
		this.minimumReadyNotify = 2;
		this.passiveEmbedMessage;
		this.mentionMessage;
		this.unreadyWhenAway = false;
		this.unreadyWhenOffline = false;
	}
	purgeMember(member){
		this.ready = filterOutArrayElement(member, this.ready);
		this.unready = filterOutArrayElement(member, this.unready);
	}
	addReady(member){
		// Remove member from both list and then add to the appropriate one.
		this.purgeMember(member);
		this.ready.push(member);
		this.passiveEmbedMessage.edit(ComposePassiveEmbed(this.channel, this));
		/*// Add readiedIcon to nickname.
		var mName = member.nickname; if(mName == null){ mName = member.user.username; }
		mName = mName.replace(readiedIcon,"");
		member.setNickname(readiedIcon + mName).catch(e => {console.log("Failed to set nickname > " + e);});*/
		this.checkReady();
	}
	removeReady(member){
		// Remove member from both list and then add to the appropriate one.
		this.purgeMember(member);
		this.unready.push(member);
		//var botlessMemberList = this.guild.members.cache.filter(member => !member.user.bot);
		this.passiveEmbedMessage.edit(ComposePassiveEmbed(this.channel, this));
		/*// Remove nickname change.
		var mName = member.nickname;
		if(mName != null){
			mName = member.nickname.replace(readiedIcon,"");
			member.setNickname(mName).catch(e => {console.log("Failed to set nickname > " + e);});
		}*/
		this.checkReady();
	}
	checkReady(){
		var totalUsers = this.guild.members.cache.filter(member => !member.user.bot).size;
		// If everyone is ready @everyone otherwise if the minimum amount are ready @ them specifically.
		if(this.ready.length >= totalUsers){
			SendMentionAll(this);
		}else if(this.ready.length >= this.minimumReadyNotify){
			RemoveMentionAll(this);
			this.ready.forEach(u => {
				u.send(this.ready.length + " people in " + this.guild.name + " are ready")
			});
		}else{
			RemoveMentionAll(this);
		}
	}
}
//==============================================================================

// Functions -------------------------------------------------------------------
async function CreateBotChannel(guild){
	console.log("Working on guild " + guild.name);
	var c = guild.channels.cache.find(channel => channel.name === botChannelName) // Find the channel named bot-readyup.
	if(c == null){ // If channel was not found create a new one.
		c = await guild.channels.create(botChannelName, { reason: 'Bot channel for ReadyUp!' })
		console.log("Creating new channel: " + c);
		if(c != null ){
			queueIndex = 0;
			queueList.forEach((item, i) => {
				if(item.guild === guild){ queueIndex = i; }
			});
			queueList[queueIndex].passiveEmbedMessage = await c.send({embed:ComposePassiveEmbed(c, queueList[queueIndex])});
		}
	}
	else{
		queueIndex = 0;
		queueList.forEach((item, i) => {
			if(item.guild === guild){ queueIndex = i; }
		});
		queueList[queueIndex].passiveEmbedMessage = await c.send({embed:ComposePassiveEmbed(c, queueList[queueIndex])});
	}
}

async function SendMentionAll(queueEntry){
	if(queueEntry.mentionMessage != null){
		queueEntry.mentionMessage = await queueEntry.mentionMessage.edit('@everyone is ready!  Get to it!');
	}
	else{
	queueEntry.mentionMessage = await queueEntry.channel.send('@everyone is ready!  Get to it!');
	}
}
async function RemoveMentionAll(queueEntry){
	if(queueEntry.mentionMessage != null){
		queueEntry.mentionMessage.delete().catch(e => {console.log("Failed to delete mention msg. > " + e);});;
		queueEntry.mentionMessage = null;
	}
}
async function SendMentionMin(queueEntry){
	if(queueEntry.mentionMessage != null){
		queueEntry.mentionMessage.delete().catch(e => {console.log("Failed to delete mention msg for min. > " + e);});;
		queueEntry.mentionMessage = null;
	}
		queueEntry.mentionMessage = await queueEntry.channel.send('@everyone ${queueEntry.ready.length} is ready!  Get to it!');
}

function ComposePassiveEmbed(botChannel, queueEntry){
	var readyString = "| "; queueEntry.ready.forEach((member, i) => { readyString += "  " + member.user.username; });
	var unreadyString = "| "; queueEntry.unready.forEach((member, i) => { unreadyString += "  " + member.user.username; });
	var settingsString = "Min Ready: " + queueEntry.minimumReadyNotify;
	if(queueEntry.unreadyWhenAway == true){ settingsString += "\nAuto unready when: Away" }
	else if(queueEntry.unreadyWhenOffline == true){ settingsString += "\nAuto unready when: Offline" }
	else{ settingsString += "\nAuto unready disabled. (Enable it with !unreadyAway or !unreadyOffline)" }

	var passiveEmbed = new Discord.MessageEmbed()
	.setTitle(" -- Ready Up! -- ")
	.setAuthor("CapnSloth")
	.setDescription("Use !ready or !unready and I'll notify you if everyone else is ready!\nSet the minimum people for a party with:  !minready *number*");

	passiveEmbed.addField("Settings:", settingsString);
	passiveEmbed.addField(" Ready! ", readyString);
	passiveEmbed.addField(" Not Ready ", unreadyString);

	return passiveEmbed;
}

function ComposeAndSendPassiveEmbed(botChannel, queueIndex){
	if(queueList[queueIndex].passiveEmbedMessage == null){
	queueList[queueIndex].passiveEmbedMessage = botChannel.send({embed:ComposePassiveEmbed(botChannel, queueList[queueIndex])});
	}
	else{
		queueList[queueIndex].passiveEmbedMessage.edit({embed:ComposePassiveEmbed(botChannel, queueList[queueIndex])});
	}
}

function RegisterGuild(guild){
	queueList.push(new readyQueue(guild)); // Add guild to list.
	
	// Debug: find 'user.id's.
	console.log("Guild: " + guild.name);
	guild.members.cache.forEach(m => { 
		console.log("user.username: " + m.user.username + "  user.id: " + m.user.id);
	});
}

function filterOutArrayElement(element, array){
	return array.filter(function(e){return e!=element});
}

function findQueueIndex(guild){
	var queueIndex = 0;
	queueList.forEach((item, i) => {
		if(item.guild === guild){ queueIndex = i; }
	});
	return queueIndex;
}

//==============================================================================

// Events ----------------------------------------------------------------------

botClient.on("ready", () => {
	//Loop through guilds and create bot channel.
	guildArray = botClient.guilds.cache.array();
	guildArray.forEach(g => RegisterGuild(g));
	guildArray.forEach(g => CreateBotChannel(g));
});

// Triggers when a new user joins the guild.
// Check that member does not already exist and then add them or override if already exist.
botClient.on("guildMemberAdd", member => {
	queueIndex = findQueueIndex(member.guild);
	var matchingMember = false;
	var i;
	var m;
	for(i = 0; i< queueList[queueIndex].unready.length; i++){
		m = queueList[queueIndex].unready[i];
		if(member.user.id == m.user.id){
			matchingMember = true;
			queueList[queueIndex].unready[i] = member;
			break;
		}
	}

	for(i = 0; i< queueList[queueIndex].ready.length; i++){
		m = queueList[queueIndex].unready[i];
		if(member.user.id == m.user.id){
			matchingMember = true;
			queueList[queueIndex].ready[i] = member;
			break;
		}
	}

	if(matchingMember == false){
		queueList[queueIndex].removeReady(member);
	}

});
// Triggers when a user leaves the guild.
botClient.on("guildMemberRemove", member => {
	queueIndex = findQueueIndex(member.guild);
	queueList[queueIndex].purgeMember(member);
	queueList[queueIndex].checkReady();
});

// Triggered when bot joins a guild.
botClient.on("guildCreate", guild =>{
	RegisterGuild(guild);
	CreateBotChannel(guild);
});

// Triggered when a message is sent over the guild.
botClient.on("message", msg => {

	// Adam torture device access:
	if(msg.author.id == adamsId){ uwuify(msg); }

	if(msg.content.toLowerCase() === "!ready"){
		queueIndex = findQueueIndex(msg.guild);
		queueList[queueIndex].addReady(msg.member); // Add member to ready list.

		msg.delete().catch(e => {console.log("Failed to delete unready msg. > " + e);}); //Remove command message once done.
	}
	if(msg.content.toLowerCase() === "!unready"){
		queueIndex = findQueueIndex(msg.guild);
		queueList[queueIndex].removeReady(msg.member);

		msg.delete().catch(e => {console.log("Failed to delete unready msg. > " + e);}); //Remove command message once done.
	}

	// Used to customise the minimumReadyNotify parameter.
	if(msg.content.toLowerCase().slice(0,9) === '!minready'){
		queueIndex = findQueueIndex(msg.guild);
		var n = parseInt(msg.content.slice(10,16), 10);
		queueList[queueIndex].minimumReadyNotify = n;

		ComposeAndSendPassiveEmbed(queueList[queueIndex].channel, queueIndex);

		msg.delete(); //Remove command message once done.
	}

	// Used to toggle the unreadyWhenAway parameter.
	if(msg.content.toLowerCase() === '!unreadyaway'){
		queueIndex = findQueueIndex(msg.guild);
		if(queueList[queueIndex].unreadyWhenAway == true){
			queueList[queueIndex].unreadyWhenAway = false;
		}else if(queueList[queueIndex].unreadyWhenAway == false){
			queueList[queueIndex].unreadyWhenAway = true;
		}

		ComposeAndSendPassiveEmbed(queueList[queueIndex].channel, queueIndex);

		msg.delete(); //Remove command message once done.
	}

	// Used to toggle the unreadyWhenOffline parameter.
	if(msg.content.toLowerCase() === '!unreadyoffline'){
		queueIndex = findQueueIndex(msg.guild);
		if(queueList[queueIndex].unreadyWhenOffline == true){
			queueList[queueIndex].unreadyWhenOffline = false;
		}else if(queueList[queueIndex].unreadyWhenOffline == false){
			queueList[queueIndex].unreadyWhenOffline = true;
		}

		ComposeAndSendPassiveEmbed(queueList[queueIndex].channel, queueIndex);

		msg.delete(); //Remove command message once done.
	}
});

botClient.on("presenceUpdate", (oldPresence, presence) => {
	if(presence != null){
		queueIndex = findQueueIndex(presence.member.guild);
		if(presence.status == "offline" && (queueList[queueIndex].unreadyWhenOffline == true || queueList[queueIndex].unreadyWhenAway == true)){
			queueList[queueIndex].removeReady(presence.member);
		}
		else if(presence.status == "idle" && queueList[queueIndex].unreadyWhenAway == true){
			queueList[queueIndex].removeReady(presence.member);
		}
	//console.log("Presence Update: " + presence.member + ", " + presence.status);
	}
	//else{
		//console.log("Presence update, but no presence");
	//}
	
});


//==============================================================================

botClient.login("NzExNzE2OTMyODM0ODIwMTE2.XsHEbg._fyxd7xLONKb-d0i9nM4IbcFGeM");
